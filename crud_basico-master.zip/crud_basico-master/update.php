<?php
include("config.php");
include("session.php");

$serie = $_POST['serie'];
$marca = $_POST['marca'];
$modelo = $_POST['modelo'];
$anios = $_POST['anios'];
$precio = $_POST['precio'];


$sql = "UPDATE autos SET marca='$marca', modelo='$modelo', anios='$anios', precio='$precio' 
WHERE marca='$serie'";
if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Registro actualizado exitósamente");';
	echo 'window.location="users.php";';
	echo '</script>';
	
} else {
	echo '<script language="javascript">';
	echo 'alert("Error en proceso de actualización de registro!");';
	echo 'window.location="users.php";';
	echo '</script>';
}
?>