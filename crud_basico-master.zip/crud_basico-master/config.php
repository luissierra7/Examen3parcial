<?php
$mysqli = new mysqli('localhost', 'root', '', 'oswa_inv7');
?>